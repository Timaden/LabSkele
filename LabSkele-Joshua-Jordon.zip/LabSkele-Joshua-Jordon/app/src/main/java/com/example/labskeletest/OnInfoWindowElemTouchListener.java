package com.example.labskeletest;

import android.view.MotionEvent;
import android.view.View;

public class OnInfoWindowElemTouchListener implements View.OnTouchListener {
    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        return false;
    }
}
